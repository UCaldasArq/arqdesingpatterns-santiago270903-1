package edu.ucaldas.estructurales.adapter;

public class ExternalXMLService {

    public String getXMLData() {
        return "<usuario>Juan</usuario>";
    }
}
