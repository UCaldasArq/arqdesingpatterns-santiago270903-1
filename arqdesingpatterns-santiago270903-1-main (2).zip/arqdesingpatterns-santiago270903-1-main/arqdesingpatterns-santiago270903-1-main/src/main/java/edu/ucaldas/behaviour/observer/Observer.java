package edu.ucaldas.comportamiento.observer;

public interface Observer {

    void update(double price);

}
