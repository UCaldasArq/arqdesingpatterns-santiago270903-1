package edu.ucaldas.comportamiento.observer;

public class Investor implements Observer {

    private String name;

    public Investor(String name) {
        this.name = name;
    }

    @Override
    public void update(double price) {

        System.out.println(
            name +
            " recibió notificación: nuevo precio = $" +
            price
        );
    }
}
