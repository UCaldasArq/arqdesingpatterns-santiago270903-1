package edu.ucaldas.comportamiento.strategy;

public class PaypalPayment implements PaymentStrategy {

    @Override
    public void pay(double amount) {
        System.out.println("Pago con PayPal por $" + amount);
    }
}
