package edu.ucaldas.comportamiento.observer;

import java.util.ArrayList;
import java.util.List;

public class Stock {

    private List<Observer> investors = new ArrayList<>();

    private double price;

    public void addObserver(Observer observer) {
        investors.add(observer);
    }

    public void removeObserver(Observer observer) {
        investors.remove(observer);
    }

    public void setPrice(double newPrice) {

        this.price = newPrice;

        notifyObservers();
    }

        private void notifyObservers() {

        for (Observer investor : investors) {
            investor.update(price);
        }
    }
}
