package edu.ucaldas;

import edu.ucaldas.comportamiento.observer.*;

public class Main {

    public static void main(String[] args) {

        Stock appleStock = new Stock();

        Investor inv1 = new Investor("Carlos");
        Investor inv2 = new Investor("Laura");
        Investor inv3 = new Investor("Andrés");

        appleStock.addObserver(inv1);
        appleStock.addObserver(inv2);
        appleStock.addObserver(inv3);

        System.out.println("Cambio de precio:\n");

        appleStock.setPrice(2450);
    }
}
