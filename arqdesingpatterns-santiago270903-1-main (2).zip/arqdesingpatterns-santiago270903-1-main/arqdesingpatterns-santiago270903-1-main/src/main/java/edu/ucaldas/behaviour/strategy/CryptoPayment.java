package edu.ucaldas.comportamiento.strategy;

public class CryptoPayment implements PaymentStrategy {

    @Override
    public void pay(double amount) {
        System.out.println("Pago con criptomonedas por $" + amount);
    }
}