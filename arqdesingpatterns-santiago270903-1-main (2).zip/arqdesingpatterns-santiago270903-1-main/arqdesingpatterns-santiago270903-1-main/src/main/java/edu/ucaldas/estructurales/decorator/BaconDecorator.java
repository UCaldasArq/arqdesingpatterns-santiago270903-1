package edu.ucaldas.estructurales.decorator;

public class BaconDecorator extends ProductDecorator {

    public BaconDecorator(Product product) {
        super(product);
    }

    @Override
    public String getDescription() {
        return product.getDescription() + ", bacon";
    }

    @Override
    public double getCost() {
        return product.getCost() + 3.000;
    }
}
