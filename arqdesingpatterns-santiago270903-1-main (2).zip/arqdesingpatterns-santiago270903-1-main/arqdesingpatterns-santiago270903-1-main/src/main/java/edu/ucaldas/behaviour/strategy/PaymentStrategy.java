package edu.ucaldas.comportamiento.strategy;

public interface PaymentStrategy {

    void pay(double amount);

}
