package edu.ucaldas.creacionales.singleton;

public class DatabaseConnection {

    // volatile evita problemas de concurrencia
    private static volatile DatabaseConnection instance;

    // Constructor privado para impedir new desde afuera
    private DatabaseConnection() {
        System.out.println("Conexión a base de datos creada");
    }

    // Singleton Thread-safe (Double Checked Locking)
    public static DatabaseConnection getInstance() {

        if (instance == null) {

            synchronized (DatabaseConnection.class) {

                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }

        return instance;
    }

    public void connect() {
        System.out.println("Conectado a la base de datos");
    }
}
