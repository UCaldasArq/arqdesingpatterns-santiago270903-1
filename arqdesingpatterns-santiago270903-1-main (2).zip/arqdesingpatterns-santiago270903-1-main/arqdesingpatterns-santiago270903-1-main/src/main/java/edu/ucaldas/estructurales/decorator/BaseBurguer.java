package edu.ucaldas.estructurales.decorator;

public class BaseBurger implements Product {

    @Override
    public String getDescription() {
        return "Hamburguesa básica";
    }

    @Override
    public double getCost() {
        return 12.000;
    }
}