package edu.ucaldas.estructurales.adapter;

public interface JsonData {

    String getJSONData();

}
