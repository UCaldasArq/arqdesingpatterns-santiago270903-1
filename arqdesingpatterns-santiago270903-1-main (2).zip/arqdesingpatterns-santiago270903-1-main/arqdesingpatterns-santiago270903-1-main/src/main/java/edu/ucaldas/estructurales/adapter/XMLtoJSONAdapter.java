package edu.ucaldas.estructurales.adapter;

public class XMLToJSONAdapter implements JsonData {

    private ExternalXMLService xmlService;

    public XMLToJSONAdapter(ExternalXMLService xmlService) {
        this.xmlService = xmlService;
    }

    @Override
    public String getJSONData() {

        String xml = xmlService.getXMLData();

        // Conversión simple simulada
        String nombre = xml
            .replace("<usuario>", "")
            .replace("</usuario>", "");

        return "{\"usuario\":\"" + nombre + "\"}";
    }
}