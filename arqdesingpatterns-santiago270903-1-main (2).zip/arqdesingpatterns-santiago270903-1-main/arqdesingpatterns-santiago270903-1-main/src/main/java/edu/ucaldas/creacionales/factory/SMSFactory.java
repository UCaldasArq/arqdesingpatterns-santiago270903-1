package edu.ucaldas.creacionales.factory;

public class SMSFactory extends NotificationFactory {

    @Override
    Notification createNotification() {
        return new SMSNotification();
    }
}
