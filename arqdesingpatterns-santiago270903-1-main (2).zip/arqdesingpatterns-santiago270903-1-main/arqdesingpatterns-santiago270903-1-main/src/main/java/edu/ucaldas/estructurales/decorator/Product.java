package edu.ucaldas.estructurales.decorator;

public interface Product {

    String getDescription();

    double getCost();
}
