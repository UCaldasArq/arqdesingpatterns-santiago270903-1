package edu.ucaldas.comportamiento.strategy;

public class CreditCardPayment implements PaymentStrategy {

    @Override
    public void pay(double amount) {
        System.out.println("Pago con tarjeta por $" + amount);
    }
}