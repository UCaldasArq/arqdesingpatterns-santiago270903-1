package edu.ucaldas.creacionales.factory;

public class EmailFactory extends NotificationFactory {

    @Override
    Notification createNotification() {
        return new EmailNotification();
    }
}
