package edu.ucaldas.creacionales.factory;

public class PushFactory extends NotificationFactory {

    @Override
    Notification createNotification() {
        return new PushNotification();
    }
}
