package edu.ucaldas.estructurales.decorator;

public class CheeseDecorator extends ProductDecorator {

    public CheeseDecorator(Product product) {
        super(product);
    }

    @Override
    public String getDescription() {
        return product.getDescription() + ", queso";
    }

    @Override
    public double getCost() {
        return product.getCost() + 2.000;
    }
}
